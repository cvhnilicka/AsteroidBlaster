package blog.gamedevelopment.box2dtutorial.views;

import blog.gamedevelopment.box2dtutorial.B2dModel;
import blog.gamedevelopment.box2dtutorial.Box2DTutorial;
import blog.gamedevelopment.box2dtutorial.controller.KeyboardController;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;

public class MainScreen implements Screen {
	private Box2DTutorial parent;
	private B2dModel model;
	private Box2DDebugRenderer debugRenderer;
	private OrthographicCamera cam;
	private KeyboardController controller;
	private Texture playerTex;
	private SpriteBatch sb;
	
	
	public MainScreen(Box2DTutorial box2dTutorial) {
		parent = box2dTutorial;
		cam = new OrthographicCamera(32,24);
		controller = new KeyboardController();
		model = new B2dModel(controller,cam,parent.assMan);
		debugRenderer = new Box2DDebugRenderer(true,true,true,true,true,true);
	
		sb = new SpriteBatch();
		sb.setProjectionMatrix(cam.combined);

		
		// tells our asset manger that we want to load the images set in loadImages method
		parent.assMan.queueAddImages();
		// tells teh asset manager to load the images and wait until finsihed loading.
		parent.assMan.manager.finishLoading();
		// gets the images as a texture
		playerTex = parent.assMan.manager.get("images/player.png");
		
		
	}

	@Override
	public void show() {
		Gdx.input.setInputProcessor(controller);	
	}

	@Override
	public void render(float delta) {
		model.logicStep(delta);
		Gdx.gl.glClearColor(0f, 0f, 0f, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		sb.begin();
		sb.draw(playerTex,model.player.getPosition().x -1,model.player.getPosition().y -1,2,2);
		sb.end();
		
		
		debugRenderer.render(model.world, cam.combined);
		
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

}
