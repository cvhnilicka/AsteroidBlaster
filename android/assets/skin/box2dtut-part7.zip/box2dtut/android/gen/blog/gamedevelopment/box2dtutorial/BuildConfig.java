/** Automatically generated file. DO NOT MODIFY */
package blog.gamedevelopment.box2dtutorial;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}